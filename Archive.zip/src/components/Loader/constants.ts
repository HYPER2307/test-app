import { Sizes } from "@/@types/sizes";

export const LOADER_SIZES: Record<Sizes, string> = {
  [Sizes.XS]: "w-4 h-4 border-2",
  [Sizes.S]: "w-6 h-6 border-4",
  [Sizes.M]: "w-9 h-9 border-4",
  [Sizes.L]: "w-12 h-12 border-8",
  [Sizes.XXL]: "w-15 h-15 border-8",
};
